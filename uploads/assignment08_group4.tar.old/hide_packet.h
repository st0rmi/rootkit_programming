#ifndef HIDE_PACKET_HEADER
#define HIDE_PACKET_HEADER

#include "include.h"

void
load_packet_hiding (char *);

void
unload_packet_hiding (void);

#endif
