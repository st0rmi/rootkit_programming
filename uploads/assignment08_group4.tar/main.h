#ifndef MAIN_HEADER
#define MAIN_HEADER

/* Information for modinfo */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Guru Chandrasekhara, Martin Herrmann");
MODULE_DESCRIPTION("A rootkit for the course Rootkit Programming at TUM in WS2014/25");

#endif
