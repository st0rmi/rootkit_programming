#ifndef GETDENTS_HEADER
#define GETDENTS_HEADER

#include "include.h"

void hook_getdents(void);
void unhook_getdents(void);

#endif
