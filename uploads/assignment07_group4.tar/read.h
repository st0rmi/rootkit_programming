#ifndef READ_HEADER 
#define READ_HEADER

#include "include.h"

void hook_read(void);
void unhook_read(void);

#endif
