#ifndef HIDE_SOCKET_HEADER
#define HIDE_SOCKET_HEADER

void hook_sockets(void);
void unhook_sockets(void);

#endif
