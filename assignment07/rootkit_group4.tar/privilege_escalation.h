#ifndef PRIVILEGE_HEADER 
#define PRIVILEGE_HEADER

void priv_escalation(void);

#endif
