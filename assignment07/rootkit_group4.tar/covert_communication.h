#ifndef COVERTCOM_HEADER
#define COVERTCOM_HEADER

void
accept_input(char input);

#endif
